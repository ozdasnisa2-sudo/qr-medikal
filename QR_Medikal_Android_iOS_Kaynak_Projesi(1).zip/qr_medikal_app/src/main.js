import { BrowserMultiFormatReader, BarcodeFormat, DecodeHintType } from '@zxing/browser';

const hints = new Map();
hints.set(DecodeHintType.POSSIBLE_FORMATS, [BarcodeFormat.QR_CODE]);
const reader = new BrowserMultiFormatReader(hints);
let scanControls = null;
let handled = false;

window.startScan = async function () {
  const msg = document.getElementById('scanMsg');
  const video = document.getElementById('video');
  if (!navigator.mediaDevices?.getUserMedia) {
    msg.textContent = 'Bu cihazda kamera erişimi kullanılamıyor. Kamera iznini ve uygulama ayarlarını kontrol et.';
    return;
  }
  try {
    window.stopScan();
    handled = false;
    msg.textContent = 'Kamera açılıyor…';
    scanControls = await reader.decodeFromVideoDevice(undefined, video, (result, error, controls) => {
      if (controls && !scanControls) scanControls = controls;
      if (!result || handled) return;
      handled = true;
      const token = result.getText();
      const patient = (window.__qrMedPatients || []).find(p => p.token === token);
      if (patient) {
        window.stopScan();
        window.openPatient(patient.id);
      } else {
        msg.textContent = 'Bu QR demo kayıtlarında bulunamadı.';
        handled = false;
      }
    });
    msg.textContent = 'Kamera açık. Demo QR kodunu göster.';
  } catch (e) {
    msg.textContent = 'Kamera açılamadı. Kamera izni verip yeniden dene.';
  }
};

window.stopScan = function () {
  if (scanControls) {
    try { scanControls.stop(); } catch (_) {}
    scanControls = null;
  }
  const video = document.getElementById('video');
  if (video) {
    const stream = video.srcObject;
    if (stream?.getTracks) stream.getTracks().forEach(track => track.stop());
    video.srcObject = null;
  }
};

// Expose the demo records to the native-compatible scanner without changing the sample data.
const exposePatients = () => {
  if (Array.isArray(window.patients)) window.__qrMedPatients = window.patients;
  else {
    // The original demo declares `const patients` in its classic script; expose it through a tiny bridge.
    const bridge = document.createElement('script');
    bridge.textContent = 'window.__qrMedPatients = patients;';
    document.body.appendChild(bridge);
  }
};
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', exposePatients, { once: true });
else exposePatients();
