# QR Medikal — Android ve iOS uygulama kaynak projesi

Bu paket, mevcut QR Medikal demo ekranını Capacitor ile Android/iOS uygulamasına dönüştürmek için hazırlanmış kaynak projedir. Gönderdiğin yeşil logo uygulama simgesi kaynağı olarak `app-icon.png` dosyasına eklendi. QR tarama, ZXing kamera tarayıcısını kullanır.

## Demo giriş
- Personel TC: `12345678912`
- Bakanlık kodu: `1032`
- Hasta kayıtları: Tamamı örnek/demo kayıtlardır.

## Geliştirme ortamı
- Node.js LTS ve npm
- Android için Android Studio + Android SDK
- iOS için macOS + Xcode (iOS uygulaması Windows'ta derlenemez)

## İlk kurulum
Proje klasöründe terminal açıp: 

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Android kamera izni için `android/app/src/main/AndroidManifest.xml` içine `<uses-permission android:name="android.permission.CAMERA" />` satırını `<application>` etiketinin dışına ekle. Android Studio'da Gradle eşitlemesi tamamlanınca test için Run kullanılabilir. APK üretmek için Android Studio menüsünden **Build > Build Bundle(s) / APK(s) > Build APK(s)**; Google Play için **Build > Generate Signed Bundle / APK > Android App Bundle** seçilir.

## iOS
Mac üzerinde: 

```bash
npm install
npm run build
npx cap add ios
npx cap sync ios
npx cap open ios
```

`ios/App/App/Info.plist` içine `NSCameraUsageDescription` anahtarı ve kamera kullanımını açıklayan bir metin ekle. Xcode'da Apple Developer hesabı / imzalama ayarları tamamlanıp cihazda test edilir. App Store gönderimi için Archive alınır.

## Logo dosyalarını platform simgelerine dönüştürme
Platform ikonlarını üretmek için: 

```bash
npm install -D @capacitor/assets
npx capacitor-assets generate --assetPath assets --iconBackgroundColor '#102c46'
```

## Önemli sınırlar
Bu bir **demo kaynak projesidir**, henüz imzalanmış APK veya IPA değildir. Bu çalışma ortamında Android SDK/Xcode imzalama yapılandırması bulunmadığından mağazaya yüklenebilir paketler burada derlenmedi. Projede istemci tarafında demo giriş doğrulaması ve örnek hasta kayıtları bulunur; gerçek hasta verisi veya gerçek Bakanlık doğrulaması için kullanılmamalıdır.
